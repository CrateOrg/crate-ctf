<?php
  header("X-flag-part-1: 2020ctf{");
  http_response_code(200);
?>
<html>
<head><title>hello</title></head>
<body>
hello
</body>
</html>
