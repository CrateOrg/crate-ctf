<?

// 2020ctf{input_sanitation_is_your_friend}
$msg=$_GET['message'];
$cmd = 'echo "' . $msg . '" >> messages';
system($cmd);

?>
<html><body><h2>Thank you for your feedback!</h2></body></html>
