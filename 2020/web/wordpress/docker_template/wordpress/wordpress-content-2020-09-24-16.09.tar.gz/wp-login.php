<?php
header("HTTP/1.1 301 Moved Permanently");
$query_str = $_SERVER['QUERY_STRING'];
if (strlen($query_str) > 0) {
  header("Location: wp_login.php?" . $query_str);
}
else {
  header("Location: wp_login.php");
}
header("X-flag-part-2: h3aderz_");
?>
